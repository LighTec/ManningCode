/*___Generated_by_IDEA___*/

/** Automatically generated file. DO NOT MODIFY */
package ar.com.daidalos.afiledialog;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}