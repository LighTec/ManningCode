/**
 * Author(s): Jainil Sutaria
 * Date Created: Nov. 4, 2016
 * Date Edited: Nov. 5, 2016
 */
package org.sintef.jarduino;

public enum PinType {
	PWM,
	Digital,
	Analog,
	Interrupt;
}
