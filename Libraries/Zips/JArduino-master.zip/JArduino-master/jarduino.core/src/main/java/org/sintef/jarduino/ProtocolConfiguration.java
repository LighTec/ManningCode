package org.sintef.jarduino;

/**
 * Created with IntelliJ IDEA.
 * User: Jonathan
 * Date: 21/08/13
 * Time: 15:04
 */
public class ProtocolConfiguration {
}
