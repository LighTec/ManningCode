
link for usb-serial-for-android-v010.jar

https://github.com/mik3y/usb-serial-for-android/releases